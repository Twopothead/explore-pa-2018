#include "common.h"
#include "x86.h"

void keyboard_event() {
}

