#ifndef __DEVICE_PALETTE_H__
#define __DEVICE_PALETTE_H__

void write_palette(void *, int);
void read_palette();

#endif
