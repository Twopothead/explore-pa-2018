#ifndef __SDL_H__
#define __SDL_H__

void init_sdl();
void close_sdl();

#endif
