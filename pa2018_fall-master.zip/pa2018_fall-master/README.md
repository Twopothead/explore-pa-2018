# PA2018 Fall

For students, DO NOT directly clone or download the code here, you will not be able to submit!

The correct way:

1. Connect to NJU campus network

2. Visit http://114.212.189.154:2000/

3. Provide your student ID to download your own install.sh script

4. Properly place the script at a good location, e.g., /home/username/

5. Execute './install.sh' from the command line and follow the instructions

Protect your install.sh script, sensitive information contained 

Contact teacher or teaching assistants if you encounter any problem

DO NOT execute others' install.sh on your own machine, this will rewrite your identity information!

# System Requirements

32-bit Debian Linux
